package com.ray.dubbo.javaspi;

public interface HelloInterface {
	public void sayHello(); 
}
